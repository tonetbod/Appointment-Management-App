base_url','http://localhost:8000/ama/');

Note: base_url should be changed to your own base_url without port "8000" 
like -----> http://localhost/ama/


DATABASE DETAILS


DB_SERVER',"localhost");

DB_USERNAME',"root");

DB_PASSWORD',"");

DB_NAME',"ama_db");



LOGIN DETAILS

S/N     USERNAME    PASSWORD    TYPE

1.      admin       admin123    ADMIN

2.      bod         bod         USER

3.      Tessy       Tessy       USER
